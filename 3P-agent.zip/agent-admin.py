from azure.ai.agents import AgentsClient
from azure.identity import DefaultAzureCredential

from dotenv import load_dotenv
import os

def delete_all_agents():
    
    # Load environment variables from .env file
    load_dotenv()
    project_endpoint = os.getenv("PROJECT_ENDPOINT")
    print(project_endpoint)

    # Authenticate using DefaultAzureCredential
    client = AgentsClient(
        endpoint=project_endpoint,
        credential=DefaultAzureCredential()
    )

    # 1. List all agents
    agents = client.list_agents()
    print("Agents found in project:")
    # for agent in agents:
    #     print(f" - ID: {agent.id}, Name: {getattr(agent, 'name', 'N/A')}")

    #2. Delete each agent
    for agent in agents:
        try:
            client.delete_agent(agent.id)
            print(f"Deleted agent: {agent.id}")
        except Exception as e:
            print(f"Failed to delete: {e}")
            continue

if __name__ == "__main__":
    delete_all_agents()
