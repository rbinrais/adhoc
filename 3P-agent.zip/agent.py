import os
from dotenv import load_dotenv
from typing import Any
from pathlib import Path
from datetime import datetime

# Add references
from azure.identity import AzureCliCredential, InteractiveBrowserCredential
from azure.ai.agents import AgentsClient
from azure.ai.agents.models import FunctionTool, ToolSet, ListSortOrder, MessageRole
from user_functions import user_functions


def main():
    # Track start time
    start_time = datetime.now()

    # Clear the console
    os.system('cls' if os.name == 'nt' else 'clear')

    # Load environment variables from .env file
    load_dotenv()
    project_endpoint = os.getenv("PROJECT_ENDPOINT")
    model_deployment = os.getenv("MODEL_DEPLOYMENT_NAME")

    print("=" * 80)
    print(f"🚀 Starting Akamai Threat Intelligence Agent session")
    print(f"   Start Time : {start_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"   Azure AI Foundry Endpoint : {project_endpoint}")
    print(f"   Model : {model_deployment}")
    print("=" * 80)

    # Connect to the Agent client (using Azure CLI credentials)
    agent_client = AgentsClient(
        endpoint=project_endpoint,
        credential=AzureCliCredential()
    )

    ##############################################
    # Read system prompt from external file
    ##############################################
    system_prompt_file = Path("system_prompt.txt")
    print(f"📖 Reading system prompt from: {system_prompt_file}")
    if not system_prompt_file.exists():
            raise FileNotFoundError(f"❌ Missing required file: {system_prompt_file}")
    with system_prompt_file.open("r", encoding="utf-8") as f:
            system_prompt = f.read().strip()
    
    # ✅ Print the loaded prompt to the console
    print("\n✅ System prompt loaded successfully:")
    print("-" * 80)
    print(system_prompt)
    print("-" * 80)
    ##############################################
            
    
    # Define an agent that can use the custom functions
    with agent_client:
        functions = FunctionTool(user_functions)
        toolset = ToolSet()
        toolset.add(functions)
        agent_client.enable_auto_function_calls(toolset)

        agent = agent_client.create_agent(
            model=model_deployment,
            name="Akamai Threat Intelligence Agent for Entra External ID",
            instructions=(
                system_prompt # 🔑 pulled in from file
            ),
            toolset=toolset
        )

        thread = agent_client.threads.create()
        print(f"🤖 Agent Ready: {agent.name} (ID: {agent.id})")
        print("-" * 80)

        # Loop until the user types 'quit'
        while True:
            user_prompt = input("Enter a prompt (or type 'quit' to exit): ")
            if user_prompt.lower() == "quit":
                break
            if len(user_prompt) == 0:
                print("Please enter a prompt.")
                continue

            message = agent_client.messages.create(
                thread_id=thread.id,
                role="user",
                content=user_prompt
            )

            run = agent_client.runs.create_and_process(
                thread_id=thread.id,
                agent_id=agent.id
            )

            if run.status == "failed":
                print(f"❌ Run failed: {run.last_error}")

            last_msg = agent_client.messages.get_last_message_text_by_role(
                thread_id=thread.id,
                role=MessageRole.AGENT,
            )
            if last_msg:
                print(f"\nAgent: {last_msg.text.value}\n")

        # Get the conversation history
        print("\n📜 Conversation Log:\n")
        messages = agent_client.messages.list(
            thread_id=thread.id,
            order=ListSortOrder.ASCENDING
        )
        for message in messages:
            if message.text_messages:
                last_msg = message.text_messages[-1]
                print(f"{message.role}: {last_msg.text.value}\n")

        # Clean up
        agent_client.delete_agent(agent.id)
        print("🗑️ Deleted agent")

    # Track end time
    end_time = datetime.now()
    elapsed = end_time - start_time

    print("=" * 80)
    print(f"✅ Session completed")
    print(f"   End Time   : {end_time.strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"   Duration   : {str(elapsed).split('.')[0]} (HH:MM:SS)")
    print("=" * 80)


if __name__ == '__main__':
    main()
