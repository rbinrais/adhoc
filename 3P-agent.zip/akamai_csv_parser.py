import pandas as pd
import ipaddress
import random

def get_random_public_ipv4():
    """Generate and return a valid random public IPv4 address."""
    while True:
        ip = ipaddress.IPv4Address(random.getrandbits(32))
        if ip.is_global:
            return str(ip)
        
def extract_high_bot_scores(csv_file: str, threshold: int = 90, sythentic: bool = False):
    required_cols = ["End-User IP", "Bot Score"]

    try:
        df = pd.read_csv(csv_file, usecols=required_cols, dtype={"Bot Score": float, "End-User IP": str})
    except Exception as e:
        print(f"❌ Error reading CSV: {e}")
        return []

    df = df.dropna(subset=required_cols)
    df = df[df["Bot Score"] >= threshold]

    results = []

    for _, row in df.iterrows():
        raw_ip = row["End-User IP"].strip()
        
        if sythentic:
            raw_ip = get_random_public_ipv4()

        score = int(row["Bot Score"])
        if not raw_ip:
            continue
        try:
            ipaddress.ip_address(raw_ip)  # validate IP
            results.append({
                "ip": raw_ip,
                "bot_score": score
            })
        except ValueError:
            print(f"⚠️ Invalid IP: {raw_ip}")
            continue

    print(f"✅ Found {len(results)} entries with Bot Score >= {threshold}.")
    return results

# Run only if executed directly
if __name__ == "__main__":
    extract_high_bot_scores("Akamai-botmanager-logs.csv")