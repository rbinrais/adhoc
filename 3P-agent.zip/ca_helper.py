import requests
import msal
import json
import time
from entra_helper import *

GRAPH_SCOPE = ["https://graph.microsoft.com/.default"]
GRAPH_ENDPOINT = "https://graph.microsoft.com/v1.0"

GLOBAL_ADMIN_ROLE_ID = "62e90394-69f5-4237-9190-012177145e10"  # Global Admin role ID

def get_access_token(client_id, client_secret, tenant_id):
    AUTHORITY = f"https://login.microsoftonline.com/{tenant_id}"
    app = msal.ConfidentialClientApplication(
        client_id=client_id,
        authority=AUTHORITY,
        client_credential=client_secret
    )
    result = app.acquire_token_for_client(scopes=GRAPH_SCOPE)
    if "access_token" in result:
        return result["access_token"]
    else:
        raise Exception("Token error: " + json.dumps(result))


def get_named_location_id_by_name(token, location_name):
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{GRAPH_ENDPOINT}/identity/conditionalAccess/namedLocations"
    resp = requests.get(url, headers=headers)
    resp.raise_for_status()
    locations = resp.json().get("value", [])
    for loc in locations:
        if loc["displayName"] == location_name:
            return loc["id"]
    return None


def get_ca_policy_block_JSON(ca_policy_name,named_location_id):
    policy_body = {
        "displayName": ca_policy_name,
        "state": "enabledForReportingButNotEnforced",
        "conditions": {
            "userRiskLevels": [],
            "signInRiskLevels": [],
            "clientAppTypes": ["all"],
            "servicePrincipalRiskLevels": [],
            "applications": {
                "includeApplications": ["None"],
                "excludeApplications": [],
                "includeUserActions": [],
                "includeAuthenticationContextClassReferences": [],
                "applicationFilter": None
            },
            "users": {
                "includeUsers": ["All"],
                "excludeUsers": [],
                "includeGroups": [],
                "excludeGroups": [],
                "includeRoles": [],
                "excludeRoles": ["62e90394-69f5-4237-9190-012177145e10"], 
                "includeGuestsOrExternalUsers": None,
                "excludeGuestsOrExternalUsers": None
            },
            "locations": {
                "includeLocations": [named_location_id],
                "excludeLocations": []
            },
            "insiderRiskLevels": None,
            "platforms": None,
            "devices": None,
            "clientApplications": None,
            "authenticationFlows": None
        },
        "grantControls": {
            "operator": "OR",
            "builtInControls": ["block"],
            "customAuthenticationFactors": [],
            "termsOfUse": [],
            "authenticationStrength": None
        }
    }
    return policy_body

def get_ca_policy_mfa_JSON(ca_policy_name,named_location_id):
    policy_body = {
                "displayName": ca_policy_name,
                "state": "enabledForReportingButNotEnforced",
                "sessionControls": None,
        "conditions": {
            "userRiskLevels": [],
            "signInRiskLevels": [],
            "clientAppTypes": [
            "all"
            ],
            "servicePrincipalRiskLevels": [],
            "insiderRiskLevels": None,
            "platforms": None,
            "devices": None,
            "clientApplications": None,
            "authenticationFlows": None,
            "applications": {
            "includeApplications": [
                "None"
            ],
            "excludeApplications": [],
            "includeUserActions": [],
            "includeAuthenticationContextClassReferences": [],
            "applicationFilter": None
            },
            "users": {
            "includeUsers": [
                "All"
            ],
            "excludeUsers": [],
            "includeGroups": [],
            "excludeGroups": [],
            "includeRoles": [],
            "excludeRoles": [
                "62e90394-69f5-4237-9190-012177145e10"
            ],
            "includeGuestsOrExternalUsers": None,
            "excludeGuestsOrExternalUsers": None
            },
            "locations": {
            "includeLocations": [named_location_id],
            "excludeLocations": []
            }
        },
        "grantControls": {
                "operator": "OR",
                "builtInControls": [
                "mfa"
                ]
            }
    }
    return policy_body

def create_or_update_ca_policy(client_id, client_secret, tenant_id,named_location_name,ca_policy_name,action):
    token = get_access_token(client_id, client_secret, tenant_id)
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    # named_location_id = get_named_location_id_by_name(token, NAMED_LOCATION_NAME)
    # if not named_location_id:
    #     print(f"❌ Named location '{NAMED_LOCATION_NAME}' not found.")
    #     return
    
    NAMED_LOCATION_NAME= named_location_name
    CA_POLICY_NAME = ca_policy_name

    ###################################################################################
    ## Named location
    ###################################################################################
    named_location_id = None
    # Retry up to 5 times to wait for named location to be available
    for attempt in range(5):
        named_location_id = get_named_location_id_by_name(token, NAMED_LOCATION_NAME)
        
        # If found, break the loop
        if named_location_id:
            break

    # If not found, wait for 1 second before retrying
    print(f"⏳ Waiting for named location '{NAMED_LOCATION_NAME}' to be available... (Attempt {attempt + 1}/5)")
    time.sleep(20)

    # If still not found after retries, exit with error
    if not named_location_id:
        print(f"❌ Named location '{NAMED_LOCATION_NAME}' not found after waiting.")
    ###################################################################################

    ###################################################################################
    ## CA Policy
    ###################################################################################    
    # Check if policy exists
    url = f"{GRAPH_ENDPOINT}/identity/conditionalAccess/policies"
    resp = requests.get(url, headers=headers)
    resp.raise_for_status()
    policies = resp.json().get("value", [])
    existing = next((p for p in policies if p["displayName"] == CA_POLICY_NAME), None)
    policy_body = ""
    if action == "block":
        policy_body =  get_ca_policy_block_JSON(CA_POLICY_NAME,named_location_id)
    if action == "mfa":
        policy_body =  get_ca_policy_mfa_JSON(CA_POLICY_NAME,named_location_id)
    
    print("\n📦 Final CA policy body:")
    print(json.dumps(policy_body, indent=2))
    try:
        if existing:
            update_url = f"{url}/{existing['id']}"
            update_resp = requests.patch(update_url, headers=headers, json=policy_body)
            update_resp.raise_for_status()
            print(f"🔄 Updated Conditional Access policy '{CA_POLICY_NAME}'. Status code: {update_resp.status_code}")
        else:
            create_resp = requests.post(url, headers=headers, json=policy_body)
            create_resp.raise_for_status()
            print(f"✅ Created Conditional Access policy '{CA_POLICY_NAME}'. Status code: {create_resp.status_code}")

    except requests.exceptions.HTTPError as http_err:
        print(f"❌ HTTP error occurred while processing policy '{CA_POLICY_NAME}': {http_err}")
        if 'update_resp' in locals() and update_resp is not None:
            print(f"Response content: {update_resp.text}")
        elif 'create_resp' in locals() and create_resp is not None:
            print(f"Response content: {create_resp.text}")
    except requests.exceptions.RequestException as req_err:
        print(f"❌ Request error occurred while processing policy '{CA_POLICY_NAME}': {req_err}")
    except Exception as err:
        print(f"❌ Unexpected error occurred while processing policy '{CA_POLICY_NAME}': {err}")


    # if existing:
    #     update_url = f"{url}/{existing['id']}"
    #     update_resp = requests.patch(update_url, headers=headers, json=policy_body)
    #     update_resp.raise_for_status()
    #     print(f"🔄 Updated Conditional Access policy '{CA_POLICY_NAME}'.")
    # else:
    #     create_resp = requests.post(url, headers=headers, json=policy_body)
    #     create_resp.raise_for_status()
    #     print(f"✅ Created Conditional Access policy '{CA_POLICY_NAME}'.")

def fetch_policy_by_display_name(display_name):
    tenant_config = get_tenant_config("external_id") 
                
    token = get_access_token(tenant_config["CLIENT_ID"],tenant_config["CLIENT_SECRET"],tenant_config["TENANT_ID"])
    headers = {
        "Authorization": f"Bearer {token}"
    }

    url = f"{GRAPH_ENDPOINT}/identity/conditionalAccess/policies"
    response = requests.get(url, headers=headers)
    response.raise_for_status()
    policies = response.json().get("value", [])

    for policy in policies:
        if policy.get("displayName") == display_name:
            print("✅ Found policy named:", display_name)
            print(json.dumps(policy, indent=2))
            return policy

    print(f"❌ Policy '{display_name}' not found.")
    return None

#🔍 Test runner
# if __name__ == "__main__":
#     fetch_policy_by_display_name("AKAMAI-BLOCK")

# # # Optional standalone test run
if __name__ == "__main__":
    #create_or_update_ca_policy()
    fetch_policy_by_display_name("AKAMAI-BLOCK")
