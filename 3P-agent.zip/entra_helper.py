import requests
import msal
import json
import ipaddress
import time
import os

from ca_helper import *

####################################################
## Tenant configuraiton
####################################################
def get_tenant_config(config_type="external_id"):
    configs = {
        "external_id": {
            "CLIENT_ID": os.getenv("EXTERNAL_CLIENT_ID"),
            "CLIENT_SECRET": os.getenv("EXTERNAL_CLIENT_SECRET"),
            "TENANT_ID": os.getenv("EXTERNAL_TENANT_ID")
        },
        "b2c": {
            "CLIENT_ID": os.getenv("B2C_CLIENT_ID"),
            "CLIENT_SECRET": os.getenv("B2C_CLIENT_SECRET"),
            "TENANT_ID": os.getenv("B2C_TENANT_ID")
        }
    }

    config_type = config_type.lower()
    config = configs.get(config_type)

    if config and all(config.values()):
        print(f"📦 Using config: {config_type}")
        print(f"    🔑 CLIENT_ID: {config['CLIENT_ID']}")
        print(f"    🏢 TENANT_ID: {config['TENANT_ID']}")
    else:
        print(f"❌ Invalid or incomplete config for type '{config_type}'. "
              f"Make sure environment variables are set.")
        config = {}

    return config

#################################################################
####### Entra Named Location Handling for IP address
#################################################################

GRAPH_SCOPE = ["https://graph.microsoft.com/.default"]
GRAPH_ENDPOINT = "https://graph.microsoft.com/v1.0"

def get_access_token(client_id, client_secret, tenant_id):
    AUTHORITY = f"https://login.microsoftonline.com/{tenant_id}"
    app = msal.ConfidentialClientApplication(
        client_id=client_id,
        authority=AUTHORITY,
        client_credential=client_secret
    )
    result = app.acquire_token_for_client(scopes=GRAPH_SCOPE)
    if "access_token" in result:
        return result["access_token"]
    else:
        raise Exception("Token error: " + json.dumps(result))


def classify_ips(ip_list):
    ipv4, ipv6 = [], []
    for ip in ip_list:
        try:
            ip_obj = ipaddress.ip_address(ip)
            if ip_obj.version == 4:
                ipv4.append(f"{ip}/32")
            elif ip_obj.version == 6:
                ipv6.append(f"{ip}/128")
        except ValueError:
            print(f"⚠️ Skipping invalid IP: {ip}")
    return ipv4, ipv6

def get_named_location_id_by_name(token, location_name):
    headers = {"Authorization": f"Bearer {token}"}
    url = f"{GRAPH_ENDPOINT}/identity/conditionalAccess/namedLocations"
    resp = requests.get(url, headers=headers)
    resp.raise_for_status()
    locations = resp.json().get("value", [])
    for loc in locations:
        if loc["displayName"] == location_name:
            return loc["id"]
    return None

def create_or_update_named_location(ip_list,client_id, client_secret, tenant_id,named_location_name):
    token = get_access_token(client_id, client_secret, tenant_id)
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }

    # Convert IPs into CIDR ranges
    ipv4_list, ipv6_list = classify_ips(ip_list)
    MAX_ALLOWED_IPS = 2000 # Max IPs Limit --> https://learn.microsoft.com/en-us/entra/identity/conditional-access/concept-assignment-network#ipv4-and-ipv6-address-ranges


    new_ip_ranges = []

    for ip in ipv4_list:
        new_ip_ranges.append({
            "@odata.type": "#microsoft.graph.iPv4CidrRange",
            "cidrAddress": ip
        })

    for ip in ipv6_list:
        new_ip_ranges.append({
            "@odata.type": "#microsoft.graph.iPv6CidrRange",
            "cidrAddress": ip
        })

    ###############################################################
    # Initialize named_location_id
    named_location_id = None

    # Retry up to 5 times to wait for named location to be available
    for attempt in range(5):
        named_location_id = get_named_location_id_by_name(token, named_location_name)
        
        # If found, break the loop
        if named_location_id:
            break

    # If not found, wait for 1 second before retrying
    print(f"⏳ Waiting for named location '{named_location_name}' to be available... (Attempt {attempt + 1}/5)")
    time.sleep(20)
    ################################################################

    # Check if named location already exists
    location_url = f"{GRAPH_ENDPOINT}/identity/conditionalAccess/namedLocations"
    resp = requests.get(location_url, headers=headers)
    resp.raise_for_status()
    locations = resp.json()["value"]

    existing_location = next((loc for loc in locations if loc["displayName"] == named_location_name), None)

    if existing_location:
        existing_id = existing_location["id"]
        existing_ranges = existing_location.get("ipRanges", [])

        # Deduplicate
        existing_set = set(item["cidrAddress"] for item in existing_ranges)
        new_set = [r for r in new_ip_ranges if r["cidrAddress"] not in existing_set]

        ## Limit MAX_ALLOWED_IPS
        combined_total = len(existing_ranges) + len(new_set)
        if combined_total > MAX_ALLOWED_IPS:
            allowed_count = MAX_ALLOWED_IPS - len(existing_ranges)
            if allowed_count <= 0:
                print("⚠️ Named location already has 2000 IPs. No update made.")
                return
            print(f"⚠️ Trimming new IPs to stay within {MAX_ALLOWED_IPS}-IP limit.")
            new_set = new_set[:allowed_count]

        if not new_set:
            print("✅ No new IPs to add. Named location already up to date.")
            return

        patch_data = {
            "@odata.type": "#microsoft.graph.ipNamedLocation",
            "ipRanges": existing_ranges + new_set
        }

        patch_url = f"{location_url}/{existing_id}"
        patch_resp = requests.patch(patch_url, headers=headers, json=patch_data)
        patch_resp.raise_for_status()
        print(f"🔄 Updated named location '{named_location_name}' with {len(new_set)} new IP(s).")

    else:
        payload = {
            "@odata.type": "#microsoft.graph.ipNamedLocation",
            "displayName": named_location_name,
            "isTrusted": False,
            "ipRanges": new_ip_ranges
        }

        post_resp = requests.post(location_url, headers=headers, json=payload)
        post_resp.raise_for_status()
        print(f"✅ Created named location '{named_location_name}' with {len(new_ip_ranges)} IP(s).")

#######################################################################


def process_ca_policy_request(ip:str,action:str):
    
    #NAMED_LOCATION_NAME = "AKAMAI-MALICIOUS-BOT-IPS"
    ca_policy_name =""
    named_location_name = ""
    if action == "block":
        ca_policy_name = "AKAMAI-BLOCK"
        named_location_name = "AKAMAI-MALICIOUS-BOT-BLOCK"
    if action == "mfa":
        ca_policy_name = "AKAMAI-MFA"
        named_location_name = "AKAMAI-MALICIOUS-BOT-MFA"
    

    tenant_config = get_tenant_config("external_id") 
    ip_list = [ip.strip()]

    create_or_update_named_location(ip_list,tenant_config["CLIENT_ID"],tenant_config["CLIENT_SECRET"],
                                    tenant_config["TENANT_ID"],named_location_name)
    
    create_or_update_ca_policy(tenant_config["CLIENT_ID"],tenant_config["CLIENT_SECRET"],
                                    tenant_config["TENANT_ID"],named_location_name,ca_policy_name,action)


def process_ca_policy_bulk_request(ip_list,action:str):
    
    #NAMED_LOCATION_NAME = "AKAMAI-MALICIOUS-BOT-IPS"
    ca_policy_name =""
    named_location_name = ""
    if action == "block":
        ca_policy_name = "AKAMAI-BLOCK"
        named_location_name = "AKAMAI-MALICIOUS-BOT-BLOCK"
    if action == "mfa":
        ca_policy_name = "AKAMAI-MFA"
        named_location_name = "AKAMAI-MALICIOUS-BOT-MFA"
    

    tenant_config = get_tenant_config("external_id") 
    #ip_list = [ip.strip()]

    create_or_update_named_location(ip_list,tenant_config["CLIENT_ID"],tenant_config["CLIENT_SECRET"],
                                    tenant_config["TENANT_ID"],named_location_name)
    
    create_or_update_ca_policy(tenant_config["CLIENT_ID"],tenant_config["CLIENT_SECRET"],
                                    tenant_config["TENANT_ID"],named_location_name,ca_policy_name,action)

if __name__ == "__main__":
    ip = "176.169.239.189"
    #ip_list = [ip.strip()]
    process_ca_policy_request(ip, "block")

