import json
from pathlib import Path
import uuid
from typing import Any, Callable, Set, Iterable, Mapping
import os

from akamai_csv_parser import extract_high_bot_scores
from entra_helper import process_ca_policy_request, process_ca_policy_bulk_request



def akamailogs() -> str:
    # print("Parsing Akamai logs [IP address and bot score]....")
    print("📥 Extracting IPs with high bot scores...")
    csv_file = os.getenv("CSV_FILE_NAME", "akamai-botmanager-logs.csv")
    threshold=50
    ip_list = extract_high_bot_scores(csv_file, threshold,True)
    print("Raw Python object:" )
    print(ip_list)
    # print      #message_json = json.dumps({"message": f"Evaluating Akamai Logs: {input_json}"})

    return ip_list

# Create a function to submit a support ticket
def evaluate(csv_entry:str) -> str:
          # Hardcoded CSV-style data
     #    data = [
     #        {"ip": "10.45.32.89", "bot_score": 99},
     #        {"ip": "8.8.8.8", "bot_score": 45},
     #        {"ip": "104.16.22.35", "bot_score": 92},
     #        {"ip": "52.13.124.7", "bot_score": 81},
     #        {"ip": "185.199.108.153", "bot_score": 68},
     #        {"ip": "34.117.59.81", "bot_score": 55}
     #    ]
        print("Agent is evaluating --> "+csv_entry)
        return csv_entry
     #message_json = json.dumps({"message": f"Evaluating Akamai Logs: {input_json}"})
     #return data

def action(ip:str, decision:str, reason:str  ) -> str:
     input_json = [
            {"ip": ip, "decision": decision, "reason": reason}
          ]

     #############################################################
     # Agent has already decided which action to take [block|mfa] and confirmed with the user. Helper Entra function call is to perform that action.
     ## Action--> CA Block 
     if decision.strip().lower() == "block":
          process_ca_policy_request(ip,decision.strip().lower())
     ## Action--> CA MFA 
     if decision.strip().lower() == "mfa":
          process_ca_policy_request(ip,decision.strip().lower())
     ###########################################################


     message_json = json.dumps({"message": f"action on logs: {input_json}"})
     #Call the Entra function to perform the CA policy related work


     print("Reviewing action...."+ message_json)
     return message_json

def bulk_action(items) -> str:
    """
    items example:
    [
      {"ip": "1.2.3.4", "bot_score": 97, "decision": "block", "reason": "bot>90"},
      {"ip": "8.8.8.8", "bot_score": 55, "decision": "mfa", "reason": "moderate risk"}
    ]
    Returns JSON string with per-item status.
    """
    print ("Inside bulk_action()...")
    print (items)
    
    if isinstance(items, str):
               try:
                    items_json = json.loads(items)
                    print (items_json)
               except json.JSONDecodeError as e:
                   print(f"[ERROR] Invalid JSON: {e}")
                   return json.dumps({"error": "Invalid JSON", "details": str(e)})

      # Now items will be a Python list
    print("DEBUG - Parsed items:", items)  # Will print as a real list, not a string
    
    ip_list_block = []
    ip_list_mfa = []

    for raw in items_json:
        ip = raw.get("ip")
        bot_score = raw.get("bot_score")
        decision = raw.get("decision", "").lower()
        reason = raw.get("reason")

        if decision == "block":
            ip_list_block.append(ip)
            print(f"DEBUG: adding IP to block list --> {ip}")
        elif decision == "mfa":
            ip_list_mfa.append(ip)
            print(f"DEBUG: adding IP to mfa list --> {ip}")

        print(f"IP: {ip} | Bot Score: {bot_score} | Decision: {decision} | Reason: {reason}")

    # Call bulk requests only if we have matching IPs
    if ip_list_block:
        print("DEBUG: calling process_ca_policy_bulk_request for block list : block")
        process_ca_policy_bulk_request(ip_list_block, "block")

    if ip_list_mfa:
        print("DEBUG: calling process_ca_policy_bulk_request for mfa list : mfa")
        process_ca_policy_bulk_request(ip_list_mfa, "mfa")

    return json.dumps({"message": "actions processed"})

# Define a set of callable functions

# Define a set of callable functions
user_functions: Set[Callable[..., Any]] = {
     akamailogs,
     evaluate, 
     action,
     bulk_action
 }